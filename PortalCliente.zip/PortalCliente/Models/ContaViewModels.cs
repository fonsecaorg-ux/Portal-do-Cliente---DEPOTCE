using System.ComponentModel.DataAnnotations;

namespace PortalCliente.Models;

public class LoginViewModel
{
    [Required(ErrorMessage = "Informe o e-mail.")]
    [EmailAddress(ErrorMessage = "E-mail inválido.")]
    [Display(Name = "E-mail")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Informe a senha.")]
    [DataType(DataType.Password)]
    [Display(Name = "Senha")]
    public string Senha { get; set; } = string.Empty;

    [Display(Name = "Manter conectado")]
    public bool LembrarMe { get; set; }
}

public class CadastroUsuarioViewModel
{
    [Required(ErrorMessage = "Informe o nome completo.")]
    [Display(Name = "Nome completo")]
    public string NomeCompleto { get; set; } = string.Empty;

    [Required(ErrorMessage = "Informe o e-mail.")]
    [EmailAddress(ErrorMessage = "E-mail inválido.")]
    [Display(Name = "E-mail")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Informe a senha.")]
    [MinLength(6, ErrorMessage = "A senha deve ter ao menos 6 caracteres.")]
    [DataType(DataType.Password)]
    [Display(Name = "Senha")]
    public string Senha { get; set; } = string.Empty;

    [Required(ErrorMessage = "Confirme a senha.")]
    [DataType(DataType.Password)]
    [Compare(nameof(Senha), ErrorMessage = "As senhas não coincidem.")]
    [Display(Name = "Confirmar senha")]
    public string ConfirmarSenha { get; set; } = string.Empty;

    /// <summary>
    /// Role do usuário: "Admin" ou "Cliente".
    /// </summary>
    [Required(ErrorMessage = "Selecione o perfil.")]
    [Display(Name = "Perfil")]
    public string Role { get; set; } = "Cliente";

    /// <summary>
    /// Nome do cliente vinculado (obrigatório quando Role == "Cliente").
    /// Deve bater com o campo Cliente nos isotanques.
    /// </summary>
    [Display(Name = "Cliente vinculado")]
    public string? ClienteNome { get; set; }
}
