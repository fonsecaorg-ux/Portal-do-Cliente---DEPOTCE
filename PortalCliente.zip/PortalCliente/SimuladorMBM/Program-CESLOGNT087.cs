using Microsoft.EntityFrameworkCore;
using SimuladorMBM.Data;
using SimuladorMBM;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddDbContext<MbmDbContext>(options =>
    options.UseSqlite("Data Source=mbm.db"));

builder.Services.AddControllers();
builder.Services.AddCors(options =>
{
    options.AddDefaultPolicy(policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<MbmDbContext>();
    db.Database.EnsureCreated();
    // Colunas adicionais: se o banco já existia, adiciona as novas (evita 500 na API).
    var colunasNovas = new[]
    {
        "PlacaVeiculo TEXT", "Tipo TEXT", "ProprietarioArmador TEXT", "DataHoraDescarregadoTerminal TEXT",
        "SlaLimite TEXT", "TestePeriodicoVencimento TEXT", "ReparoAcumuladoValor REAL", "UrlsFotos TEXT",
        "Patio TEXT", "Bloco TEXT", "Fila TEXT", "Pilha TEXT", "UrlCertificadoLavagem TEXT", "UrlLaudoVistoria TEXT"
    };
    foreach (var col in colunasNovas)
    {
        try
        {
#pragma warning disable EF1002 // SQL é DDL com nomes fixos (array colunasNovas), sem entrada do usuário
            await db.Database.ExecuteSqlRawAsync($"ALTER TABLE Isotanques ADD COLUMN {col}");
#pragma warning restore EF1002
        }
        catch (Microsoft.Data.Sqlite.SqliteException)
        {
            // Coluna já existe — ignorar
        }
    }
    await SeedData.EnsureSeedAsync(db);
}

app.UseCors();
app.MapControllers();

// Página inicial: explicação + link para o painel
app.MapGet("/", () => Results.Content("""
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Simulador MBM</title>
    <style>
        body { font-family: Segoe UI, sans-serif; max-width: 600px; margin: 40px auto; padding: 20px; }
        h1 { color: #0d6efd; }
        .ok { color: #198754; font-weight: bold; }
        .btn { display: inline-block; margin-top: 16px; padding: 10px 20px; background: #0d6efd; color: white; text-decoration: none; border-radius: 6px; }
        .btn:hover { background: #0b5ed7; }
        ul { line-height: 1.8; }
        a { color: #0d6efd; }
    </style>
</head>
<body>
    <h1>Simulador MBM – API</h1>
    <p class="ok">✓ API rodando corretamente.</p>
    <p>O MBM é o <strong>sistema base</strong>: aqui ficam os dados (isotanques, clientes, status). Quem mostra dashboards e telas para o cliente é o <strong>Portal</strong> (outra aplicação que consome esta API).</p>
    <p><a href="/painel" class="btn">Ver painel com os dados do MBM</a></p>
    <p>Endpoints da API:</p>
    <ul>
        <li><a href="/api/isotanques">/api/isotanques</a> – lista de isotanques</li>
        <li><a href="/api/clientes">/api/clientes</a> – lista de clientes</li>
        <li><a href="/api/status">/api/status</a> – lista de status</li>
    </ul>
    <p>Próximo passo: rode o <strong>Portal do Cliente</strong> em outro terminal e acesse <strong>http://localhost:5187</strong> para ver as telas que o cliente usa.</p>
</body>
</html>
""", "text/html"));

// Painel: resumo visual dos dados que o MBM guarda (para você “ver” o que é o MBM)
app.MapPainelRoutes();

app.Run();
