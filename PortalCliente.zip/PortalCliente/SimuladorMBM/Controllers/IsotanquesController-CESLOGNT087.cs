using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using SimuladorMBM.Data;
using SimuladorMBM.Models;

namespace SimuladorMBM.Controllers;

/// <summary>
/// API de isotanques — simula o que o MBM expõe para o Portal do Cliente.
/// </summary>
[ApiController]
[Route("api/[controller]")]
public class IsotanquesController : ControllerBase
{
    private readonly MbmDbContext _db;

    public IsotanquesController(MbmDbContext db)
    {
        _db = db;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<IsotanqueDto>>> Get(
        [FromQuery] string? cliente,
        [FromQuery] string? status,
        [FromQuery] string? busca,
        CancellationToken cancellationToken = default)
    {
        try
        {
            var list = await ListarIsotanquesAsync(cliente, status, busca, cancellationToken);
            return Ok(list);
        }
        catch (Exception ex)
        {
            var logger = HttpContext.RequestServices.GetService<ILogger<IsotanquesController>>();
            logger?.LogWarning(ex, "Erro ao listar isotanques. Tentando adicionar coluna PlacaVeiculo e repetir.");
            try
            {
                await _db.Database.ExecuteSqlRawAsync("ALTER TABLE Isotanques ADD COLUMN PlacaVeiculo TEXT");
            }
            catch (Microsoft.Data.Sqlite.SqliteException)
            {
                // Coluna já existe
            }
            try
            {
                var list = await ListarIsotanquesAsync(cliente, status, busca, cancellationToken);
                return Ok(list);
            }
            catch (Exception ex2)
            {
                logger?.LogError(ex2, "Erro ao listar isotanques. Apague mbm.db na pasta SimuladorMBM e rode o Simulador de novo.");
                return Ok(new List<IsotanqueDto>());
            }
        }
    }

    private async Task<List<IsotanqueDto>> ListarIsotanquesAsync(string? cliente, string? status, string? busca, CancellationToken cancellationToken)
    {
        var query = _db.Isotanques
            .AsNoTracking()
            .Include(i => i.Cliente)
            .Include(i => i.Produto)
            .Where(i => i.Ativo);

        if (!string.IsNullOrWhiteSpace(cliente))
            query = query.Where(i => i.Cliente.Nome == cliente);
        if (!string.IsNullOrWhiteSpace(status))
            query = query.Where(i => i.Status == status);
        if (!string.IsNullOrWhiteSpace(busca))
            query = query.Where(i => i.Codigo.Contains(busca) || i.Produto.Nome.Contains(busca));

        var hoje = DateTime.Today;
        var raw = await query
            .OrderBy(i => i.Codigo)
            .Select(i => new
            {
                i.Id, i.Codigo,
                Produto = i.Produto.Nome,
                Cliente = i.Cliente.Nome,
                i.Status, i.DataInicioStatus, i.DataEntrada, i.PrevisaoLiberacao,
                i.DataHoraDescarregadoPatio, i.DataHoraDescarregadoTerminal, i.DataHoraCarregadoVeiculo,
                i.PrevisaoChegadaTerminal, i.UrlFoto, i.UrlsFotos, i.PlacaVeiculo,
                i.Tipo, i.ProprietarioArmador, i.SlaLimite, i.TestePeriodicoVencimento, i.ReparoAcumuladoValor,
                i.Patio, i.Bloco, i.Fila, i.Pilha, i.UrlCertificadoLavagem, i.UrlLaudoVistoria
            })
            .ToListAsync(cancellationToken);

        return raw.Select(i => new IsotanqueDto
        {
            Id = i.Id, Codigo = i.Codigo, Produto = i.Produto, Cliente = i.Cliente,
            Status = i.Status,
            DiasNoStatus = i.DataInicioStatus.HasValue ? (int)(hoje - i.DataInicioStatus.Value.Date).TotalDays : null,
            DataEntrada = i.DataEntrada,
            DataInicioStatus = i.DataInicioStatus,
            PrevisaoLiberacao = i.PrevisaoLiberacao,
            DataHoraDescarregadoPatio = i.DataHoraDescarregadoPatio,
            DataHoraDescarregadoTerminal = i.DataHoraDescarregadoTerminal,
            DataHoraCarregadoVeiculo = i.DataHoraCarregadoVeiculo,
            PrevisaoChegadaTerminal = i.PrevisaoChegadaTerminal,
            UrlFoto = i.UrlFoto,
            UrlsFotos = i.UrlsFotos,
            PlacaVeiculo = i.PlacaVeiculo,
            Tipo = i.Tipo,
            ProprietarioArmador = i.ProprietarioArmador,
            SlaLimite = i.SlaLimite,
            TestePeriodicoVencimento = i.TestePeriodicoVencimento,
            ReparoAcumuladoValor = i.ReparoAcumuladoValor,
            Patio = i.Patio, Bloco = i.Bloco, Fila = i.Fila, Pilha = i.Pilha,
            UrlCertificadoLavagem = i.UrlCertificadoLavagem,
            UrlLaudoVistoria = i.UrlLaudoVistoria
        }).ToList();
    }

    [HttpGet("{codigo}")]
    public async Task<ActionResult<IsotanqueDto>> GetPorCodigo(string codigo, CancellationToken cancellationToken = default)
    {
        try
        {
            var hoje = DateTime.Today;
            var raw = await _db.Isotanques
                .AsNoTracking()
                .Include(i => i.Cliente)
                .Include(i => i.Produto)
                .Where(i => i.Ativo && i.Codigo == codigo)
                .Select(i => new
                {
                    i.Id, i.Codigo,
                    Produto = i.Produto.Nome,
                    Cliente = i.Cliente.Nome,
                    i.Status, i.DataInicioStatus, i.DataEntrada, i.PrevisaoLiberacao,
                    i.DataHoraDescarregadoPatio, i.DataHoraDescarregadoTerminal, i.DataHoraCarregadoVeiculo,
                    i.PrevisaoChegadaTerminal, i.UrlFoto, i.UrlsFotos, i.PlacaVeiculo,
                    i.Tipo, i.ProprietarioArmador, i.SlaLimite, i.TestePeriodicoVencimento, i.ReparoAcumuladoValor,
                    i.Patio, i.Bloco, i.Fila, i.Pilha, i.UrlCertificadoLavagem, i.UrlLaudoVistoria
                })
                .FirstOrDefaultAsync(cancellationToken);

            if (raw == null) return NotFound();

            return Ok(new IsotanqueDto
            {
                Id = raw.Id, Codigo = raw.Codigo, Produto = raw.Produto, Cliente = raw.Cliente,
                Status = raw.Status,
                DiasNoStatus = raw.DataInicioStatus.HasValue ? (int)(hoje - raw.DataInicioStatus.Value.Date).TotalDays : null,
                DataEntrada = raw.DataEntrada,
                DataInicioStatus = raw.DataInicioStatus,
                PrevisaoLiberacao = raw.PrevisaoLiberacao,
                DataHoraDescarregadoPatio = raw.DataHoraDescarregadoPatio,
                DataHoraDescarregadoTerminal = raw.DataHoraDescarregadoTerminal,
                DataHoraCarregadoVeiculo = raw.DataHoraCarregadoVeiculo,
                PrevisaoChegadaTerminal = raw.PrevisaoChegadaTerminal,
                UrlFoto = raw.UrlFoto,
                UrlsFotos = raw.UrlsFotos,
                PlacaVeiculo = raw.PlacaVeiculo,
                Tipo = raw.Tipo,
                ProprietarioArmador = raw.ProprietarioArmador,
                SlaLimite = raw.SlaLimite,
                TestePeriodicoVencimento = raw.TestePeriodicoVencimento,
                ReparoAcumuladoValor = raw.ReparoAcumuladoValor,
                Patio = raw.Patio, Bloco = raw.Bloco, Fila = raw.Fila, Pilha = raw.Pilha,
                UrlCertificadoLavagem = raw.UrlCertificadoLavagem,
                UrlLaudoVistoria = raw.UrlLaudoVistoria
            });
        }
        catch (Exception ex)
        {
            var logger = HttpContext.RequestServices.GetService<ILogger<IsotanquesController>>();
            logger?.LogError(ex, "Erro ao buscar isotanque por código.");
            return NotFound();
        }
    }
}