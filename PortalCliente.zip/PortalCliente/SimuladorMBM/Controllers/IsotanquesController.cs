using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SimuladorMBM.Data;
using SimuladorMBM.Models;

namespace SimuladorMBM.Controllers;

/// <summary>
/// API de isotanques — simula o que o MBM expõe para o Portal do Cliente.
/// </summary>
[ApiController]
[Route("api/[controller]")]
public class IsotanquesController : ControllerBase
{
    private readonly MbmDbContext _db;

    public IsotanquesController(MbmDbContext db)
    {
        _db = db;
    }

    /// <summary>
    /// Lista isotanques com filtros opcionais (cliente, status, busca).
    /// Retorna DTO compatível com o modelo do Portal.
    /// </summary>
    [HttpGet]
    public async Task<ActionResult<IEnumerable<IsotanqueDto>>> Get(
        [FromQuery] string? cliente,
        [FromQuery] string? status,
        [FromQuery] string? busca,
        CancellationToken cancellationToken = default)
    {
        var query = _db.Isotanques
            .AsNoTracking()
            .Include(i => i.Cliente)
            .Include(i => i.Produto)
            .Where(i => i.Ativo);

        if (!string.IsNullOrWhiteSpace(cliente))
            query = query.Where(i => i.Cliente.Nome == cliente);

        if (!string.IsNullOrWhiteSpace(status))
            query = query.Where(i => i.Status == status);

        if (!string.IsNullOrWhiteSpace(busca))
            query = query.Where(i => i.Codigo.Contains(busca) || i.Produto.Nome.Contains(busca));

        var hoje = DateTime.Today;
        var raw = await query
            .OrderBy(i => i.Codigo)
            .Select(i => new
            {
                i.Id,
                i.Codigo,
                Produto = i.Produto.Nome,
                Cliente = i.Cliente.Nome,
                i.Status,
                i.DataInicioStatus,
                i.PrevisaoLiberacao,
                i.DataHoraDescarregadoPatio,
                i.DataHoraCarregadoVeiculo,
                i.PrevisaoChegadaTerminal,
                i.UrlFoto
            })
            .ToListAsync(cancellationToken);

        var list = raw.Select(i => new IsotanqueDto
        {
            Id = i.Id,
            Codigo = i.Codigo,
            Produto = i.Produto,
            Cliente = i.Cliente,
            Status = i.Status,
            DiasNoStatus = i.DataInicioStatus.HasValue ? (int)(hoje - i.DataInicioStatus.Value.Date).TotalDays : null,
            PrevisaoLiberacao = i.PrevisaoLiberacao,
            DataHoraDescarregadoPatio = i.DataHoraDescarregadoPatio,
            DataHoraCarregadoVeiculo = i.DataHoraCarregadoVeiculo,
            PrevisaoChegadaTerminal = i.PrevisaoChegadaTerminal,
            UrlFoto = i.UrlFoto
        }).ToList();

        return Ok(list);
    }

    /// <summary>
    /// Busca isotanque por código.
    /// </summary>
    [HttpGet("{codigo}")]
    public async Task<ActionResult<IsotanqueDto>> GetPorCodigo(string codigo, CancellationToken cancellationToken = default)
    {
        var hoje = DateTime.Today;
        var raw = await _db.Isotanques
            .AsNoTracking()
            .Include(i => i.Cliente)
            .Include(i => i.Produto)
            .Where(i => i.Ativo && i.Codigo == codigo)
            .Select(i => new
            {
                i.Id,
                i.Codigo,
                Produto = i.Produto.Nome,
                Cliente = i.Cliente.Nome,
                i.Status,
                i.DataInicioStatus,
                i.PrevisaoLiberacao,
                i.DataHoraDescarregadoPatio,
                i.DataHoraCarregadoVeiculo,
                i.PrevisaoChegadaTerminal,
                i.UrlFoto
            })
            .FirstOrDefaultAsync(cancellationToken);

        if (raw == null)
            return NotFound();

        var item = new IsotanqueDto
        {
            Id = raw.Id,
            Codigo = raw.Codigo,
            Produto = raw.Produto,
            Cliente = raw.Cliente,
            Status = raw.Status,
            DiasNoStatus = raw.DataInicioStatus.HasValue ? (int)(hoje - raw.DataInicioStatus.Value.Date).TotalDays : null,
            PrevisaoLiberacao = raw.PrevisaoLiberacao,
            DataHoraDescarregadoPatio = raw.DataHoraDescarregadoPatio,
            DataHoraCarregadoVeiculo = raw.DataHoraCarregadoVeiculo,
            PrevisaoChegadaTerminal = raw.PrevisaoChegadaTerminal,
            UrlFoto = raw.UrlFoto
        };

        return Ok(item);
    }
}