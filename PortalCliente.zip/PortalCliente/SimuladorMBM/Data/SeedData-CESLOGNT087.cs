using Microsoft.EntityFrameworkCore;
using SimuladorMBM.Models;

namespace SimuladorMBM.Data;

/// <summary>
/// Carga inicial do MBM simulado: clientes, produtos, status e isotanques.
/// Dados realistas com diferentes estágios do ciclo de vida.
/// </summary>
public static class SeedData
{
    public static async Task EnsureSeedAsync(MbmDbContext db)
    {
        if (await db.Isotanques.AnyAsync())
            return;

        var statusList = new[]
        {
            new StatusIsotanque { Codigo = "AG_OFF_HIRE", Descricao = "Ag. Off Hire", Ordem = 1 },
            new StatusIsotanque { Codigo = "AG_ENVIO_ESTIMATIVA", Descricao = "Ag. Envio Estimativa", Ordem = 2 },
            new StatusIsotanque { Codigo = "AG_LIMPEZA", Descricao = "Ag. Limpeza", Ordem = 3 },
            new StatusIsotanque { Codigo = "AG_REPARO", Descricao = "Ag. Reparo", Ordem = 4 },
            new StatusIsotanque { Codigo = "AG_INSPECAO", Descricao = "Ag. Inspeção", Ordem = 5 },
        };
        await db.StatusIsotanques.AddRangeAsync(statusList);
        await db.SaveChangesAsync();

        var clientes = new[]
        {
            new Cliente { Codigo = "DH", Nome = "DEN HARTOGH", EmailContato = "contato@denhartogh.com" },
            new Cliente { Codigo = "EA", Nome = "Empresa Alpha", EmailContato = "logistica@empresaalpha.com" },
            new Cliente { Codigo = "QB", Nome = "Química Beta", EmailContato = "operacoes@quimicabeta.com" },
        };
        await db.Clientes.AddRangeAsync(clientes);
        await db.SaveChangesAsync();

        var produtos = new[]
        {
            new Produto { Codigo = "ET", Nome = "Etanol", ClasseRisco = "3" },
            new Produto { Codigo = "MT", Nome = "Metanol", ClasseRisco = "3" },
            new Produto { Codigo = "AC", Nome = "Ácido acético", ClasseRisco = "8" },
            new Produto { Codigo = "TL", Nome = "Tolueno", ClasseRisco = "3" },
            new Produto { Codigo = "PG", Nome = "Propilenoglicol", ClasseRisco = "0" },
            new Produto { Codigo = "HX", Nome = "Hexano", ClasseRisco = "3" },
        };
        await db.Produtos.AddRangeAsync(produtos);
        await db.SaveChangesAsync();

        var hoje = DateTime.Today;
        var agora = DateTime.Now;

        var dh = await db.Clientes.FirstAsync(c => c.Codigo == "DH");
        var ea = await db.Clientes.FirstAsync(c => c.Codigo == "EA");
        var qb = await db.Clientes.FirstAsync(c => c.Codigo == "QB");
        var etanol = await db.Produtos.FirstAsync(p => p.Codigo == "ET");
        var metanol = await db.Produtos.FirstAsync(p => p.Codigo == "MT");
        var acido = await db.Produtos.FirstAsync(p => p.Codigo == "AC");
        var tolueno = await db.Produtos.FirstAsync(p => p.Codigo == "TL");
        var propilenoglicol = await db.Produtos.FirstAsync(p => p.Codigo == "PG");
        var hexano = await db.Produtos.FirstAsync(p => p.Codigo == "HX");

        var isotanques = new List<Isotanque>
        {
            // ── DEN HARTOGH ────────────────────────────────────────────────

            // Processo completo: chegou, limpou, carregou, já tem placa e previsão terminal
            new() {
                Codigo = "DHDU1274480", ProdutoId = etanol.Id, ClienteId = dh.Id,
                Status = "Ag. Envio Estimativa",
                DataInicioStatus = hoje.AddDays(-2),
                PrevisaoLiberacao = hoje.AddDays(3),
                DataEntrada = hoje.AddDays(-10),
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddDays(-10).AddHours(8),
                DataHoraCarregadoVeiculo = agora.AddDays(-1).AddHours(14),
                PrevisaoChegadaTerminal = hoje.AddDays(2).AddHours(10),
                PlacaVeiculo = "BRA2E19",
                UrlFoto = "https://placehold.co/400x200/0d6efd/white?text=DHDU1274480",
                Tipo = "T14", ProprietarioArmador = "DEN HARTOGH",
                DataHoraDescarregadoTerminal = agora.AddDays(-11).AddHours(10),
                SlaLimite = hoje.AddDays(3).AddHours(18), TestePeriodicoVencimento = new DateTime(2027, 6, 15),
                ReparoAcumuladoValor = 0, Patio = "A", Bloco = "1", Fila = "02", Pilha = "1",
                UrlsFotos = "https://placehold.co/400x200/0d6efd/white?text=DHDU1274480,https://placehold.co/300x200/198754/white?text=foto2"
            },

            // Recém chegado — só tem data de chegada no pátio, aguardando limpeza
            new() {
                Codigo = "DHDL2272373", ProdutoId = metanol.Id, ClienteId = dh.Id,
                Status = "Ag. Limpeza",
                DataInicioStatus = hoje,
                PrevisaoLiberacao = hoje.AddDays(7),
                DataEntrada = hoje,
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddHours(-3),
                UrlFoto = "https://placehold.co/400x200/198754/white?text=DHDL2272373",
                Tipo = "T11", SlaLimite = hoje.AddDays(7).AddHours(12), TestePeriodicoVencimento = new DateTime(2026, 12, 1),
                Patio = "A", Bloco = "2", Fila = "01", Pilha = "1"
            },

            // Em limpeza há alguns dias — chegou, está no processo
            new() {
                Codigo = "DHDU2273512", ProdutoId = acido.Id, ClienteId = dh.Id,
                Status = "Ag. Limpeza",
                DataInicioStatus = hoje.AddDays(-4),
                PrevisaoLiberacao = hoje.AddDays(3),
                DataEntrada = hoje.AddDays(-6),
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddDays(-6).AddHours(7),
                UrlFoto = "https://placehold.co/400x200/6f42c1/white?text=DHDU2273512"
            },

            // Aguardando reparo — chegou há bastante tempo, problema identificado
            new() {
                Codigo = "DHDL3399881", ProdutoId = acido.Id, ClienteId = dh.Id,
                Status = "Ag. Reparo",
                DataInicioStatus = hoje.AddDays(-15),
                PrevisaoLiberacao = hoje.AddDays(10),
                DataEntrada = hoje.AddDays(-20),
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddDays(-20).AddHours(9),
                Tipo = "T14", ReparoAcumuladoValor = 18450.00m, SlaLimite = hoje.AddDays(10),
                Patio = "B", Bloco = "1", Fila = "05", Pilha = "2", UrlLaudoVistoria = "https://example.com/laudo/DHDL3399881.pdf"
            },

            // Pronto: limpou, carregou, tem placa, aguardando envio de estimativa
            new() {
                Codigo = "DHDU4455667", ProdutoId = tolueno.Id, ClienteId = dh.Id,
                Status = "Ag. Envio Estimativa",
                DataInicioStatus = hoje.AddDays(-1),
                PrevisaoLiberacao = hoje.AddDays(5),
                DataEntrada = hoje.AddDays(-8),
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddDays(-8).AddHours(11),
                DataHoraCarregadoVeiculo = agora.AddDays(-1).AddHours(16),
                PlacaVeiculo = "ABC1D23"
            },

            // Em inspeção após limpeza
            new() {
                Codigo = "DHDU1971099", ProdutoId = etanol.Id, ClienteId = dh.Id,
                Status = "Ag. Inspeção",
                DataInicioStatus = hoje.AddDays(-2),
                PrevisaoLiberacao = hoje.AddDays(4),
                DataEntrada = hoje.AddDays(-9),
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddDays(-9).AddHours(6),
                UrlFoto = "https://placehold.co/400x200/dc3545/white?text=DHDU1971099"
            },

            // Inspeção há muito tempo — possível problema
            new() {
                Codigo = "DHDU3012345", ProdutoId = metanol.Id, ClienteId = dh.Id,
                Status = "Ag. Inspeção",
                DataInicioStatus = hoje.AddDays(-12),
                PrevisaoLiberacao = hoje.AddDays(8),
                DataEntrada = hoje.AddDays(-14),
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddDays(-14).AddHours(9)
            },

            // Processo completo: tudo preenchido, pronto para embarque
            new() {
                Codigo = "DHDL1122334", ProdutoId = propilenoglicol.Id, ClienteId = dh.Id,
                Status = "Ag. Envio Estimativa",
                DataInicioStatus = hoje,
                PrevisaoLiberacao = hoje.AddDays(2),
                DataEntrada = hoje.AddDays(-12),
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddDays(-12).AddHours(8),
                DataHoraCarregadoVeiculo = agora.AddHours(-4),
                PrevisaoChegadaTerminal = hoje.AddDays(1).AddHours(18),
                PlacaVeiculo = "MNO3F45",
                UrlFoto = "https://placehold.co/400x200/fd7e14/white?text=DHDL1122334"
            },

            // Off hire — parado há muito tempo, sem previsão
            new() {
                Codigo = "DHDU8899001", ProdutoId = etanol.Id, ClienteId = dh.Id,
                Status = "Ag. Off Hire",
                DataInicioStatus = hoje.AddDays(-45),
                PrevisaoLiberacao = null,
                DataEntrada = hoje.AddDays(-45),
                UltimaAtualizacao = hoje
            },

            // Reparo leve, chegou ontem
            new() {
                Codigo = "DHDL6677889", ProdutoId = metanol.Id, ClienteId = dh.Id,
                Status = "Ag. Reparo",
                DataInicioStatus = hoje.AddDays(-1),
                PrevisaoLiberacao = hoje.AddDays(14),
                DataEntrada = hoje.AddDays(-1),
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddDays(-1).AddHours(10)
            },

            // ── EMPRESA ALPHA ──────────────────────────────────────────────

            // Recém chegado, aguardando limpeza
            new() {
                Codigo = "EXFU5567363", ProdutoId = etanol.Id, ClienteId = ea.Id,
                Status = "Ag. Limpeza",
                DataInicioStatus = hoje,
                PrevisaoLiberacao = hoje.AddDays(5),
                DataEntrada = hoje,
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddHours(-2)
            },

            // Processo completo com placa e previsão terminal
            new() {
                Codigo = "EXFU6422402", ProdutoId = metanol.Id, ClienteId = ea.Id,
                Status = "Ag. Envio Estimativa",
                DataInicioStatus = hoje.AddDays(-1),
                PrevisaoLiberacao = hoje.AddDays(2),
                DataEntrada = hoje.AddDays(-7),
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddDays(-7).AddHours(14),
                DataHoraCarregadoVeiculo = agora.AddDays(-1).AddHours(9),
                PrevisaoChegadaTerminal = hoje.AddDays(1).AddHours(14),
                PlacaVeiculo = "DEF4G56",
                UrlFoto = "https://placehold.co/400x200/0dcaf0/white?text=EXFU6422402",
                Tipo = "T14", ProprietarioArmador = "Empresa Alpha",
                DataHoraDescarregadoTerminal = agora.AddDays(-8).AddHours(10),
                SlaLimite = hoje.AddDays(2).AddHours(14), TestePeriodicoVencimento = new DateTime(2027, 3, 1),
                ReparoAcumuladoValor = 12450.00m, Patio = "A", Bloco = "3", Fila = "02", Pilha = "1",
                UrlsFotos = "https://placehold.co/400x200/0dcaf0/white?text=EXFU6422402,https://placehold.co/300x200/0dcaf0/white?text=vistoria",
                UrlCertificadoLavagem = "https://example.com/cert/EXFU6422402.pdf", UrlLaudoVistoria = "https://example.com/eir/EXFU6422402.pdf"
            },

            // Em inspeção
            new() {
                Codigo = "EXFU6632144", ProdutoId = tolueno.Id, ClienteId = ea.Id,
                Status = "Ag. Inspeção",
                DataInicioStatus = hoje.AddDays(-3),
                PrevisaoLiberacao = hoje.AddDays(6),
                DataEntrada = hoje.AddDays(-5),
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddDays(-5).AddHours(8)
            },

            // Reparo demorado
            new() {
                Codigo = "EXFU7711223", ProdutoId = hexano.Id, ClienteId = ea.Id,
                Status = "Ag. Reparo",
                DataInicioStatus = hoje.AddDays(-18),
                PrevisaoLiberacao = hoje.AddDays(15),
                DataEntrada = hoje.AddDays(-20),
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddDays(-20).AddHours(11)
            },

            // Limpeza em andamento
            new() {
                Codigo = "EXFU9988776", ProdutoId = metanol.Id, ClienteId = ea.Id,
                Status = "Ag. Limpeza",
                DataInicioStatus = hoje.AddDays(-2),
                PrevisaoLiberacao = hoje.AddDays(3),
                DataEntrada = hoje.AddDays(-4),
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddDays(-4).AddHours(15)
            },

            // Pronto, carregado, aguardando envio
            new() {
                Codigo = "EXFU9900112", ProdutoId = tolueno.Id, ClienteId = ea.Id,
                Status = "Ag. Envio Estimativa",
                DataInicioStatus = hoje.AddDays(-3),
                PrevisaoLiberacao = hoje.AddDays(4),
                DataEntrada = hoje.AddDays(-11),
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddDays(-11).AddHours(7),
                DataHoraCarregadoVeiculo = agora.AddDays(-3).AddHours(13),
                PlacaVeiculo = "GHI5H67",
                Tipo = "T14", SlaLimite = hoje.AddDays(4).AddHours(18), TestePeriodicoVencimento = new DateTime(2027, 8, 15),
                ReparoAcumuladoValor = 3200.00m, Patio = "A", Bloco = "2", Fila = "04", Pilha = "1"
            },

            // ── QUÍMICA BETA ───────────────────────────────────────────────

            // Recém chegado hoje
            new() {
                Codigo = "SEDU8063278", ProdutoId = acido.Id, ClienteId = qb.Id,
                Status = "Ag. Limpeza",
                DataInicioStatus = hoje,
                PrevisaoLiberacao = hoje.AddDays(6),
                DataEntrada = hoje,
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddHours(-1)
            },

            // Off hire há muito tempo
            new() {
                Codigo = "SEDU5544332", ProdutoId = etanol.Id, ClienteId = qb.Id,
                Status = "Ag. Off Hire",
                DataInicioStatus = hoje.AddDays(-60),
                PrevisaoLiberacao = null,
                DataEntrada = hoje.AddDays(-60),
                UltimaAtualizacao = hoje
            },

            // Processo completo: chegou, limpou, carregou, com placa
            new() {
                Codigo = "SEDU2233445", ProdutoId = etanol.Id, ClienteId = qb.Id,
                Status = "Ag. Envio Estimativa",
                DataInicioStatus = hoje,
                PrevisaoLiberacao = hoje.AddDays(2),
                DataEntrada = hoje.AddDays(-9),
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddDays(-9).AddHours(8),
                DataHoraCarregadoVeiculo = agora.AddHours(-5),
                PrevisaoChegadaTerminal = hoje.AddDays(1).AddHours(20),
                PlacaVeiculo = "JKL6I78",
                UrlFoto = "https://placehold.co/400x200/6610f2/white?text=SEDU2233445",
                Tipo = "T11", SlaLimite = hoje.AddDays(2).AddHours(20), TestePeriodicoVencimento = new DateTime(2026, 11, 1),
                Patio = "B", Bloco = "2", Fila = "01", Pilha = "1", UrlCertificadoLavagem = "https://example.com/cert/SEDU2233445.pdf"
            },

            // Em limpeza há poucos dias
            new() {
                Codigo = "SEDU7788990", ProdutoId = hexano.Id, ClienteId = qb.Id,
                Status = "Ag. Limpeza",
                DataInicioStatus = hoje.AddDays(-3),
                PrevisaoLiberacao = hoje.AddDays(4),
                DataEntrada = hoje.AddDays(-5),
                UltimaAtualizacao = hoje,
                DataHoraDescarregadoPatio = agora.AddDays(-5).AddHours(13)
            },
        };

        await db.Isotanques.AddRangeAsync(isotanques);
        await db.SaveChangesAsync();
    }
}