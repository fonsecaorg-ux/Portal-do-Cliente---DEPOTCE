namespace SimuladorMBM.Models;

/// <summary>
/// DTO retornado pela API do MBM — compatível com o modelo Container do Portal.
/// Inclui todos os campos possíveis para o portal espelhar o MBM completo.
/// </summary>
public class IsotanqueDto
{
    public int Id { get; set; }
    public string Codigo { get; set; } = string.Empty;
    public string Produto { get; set; } = string.Empty;
    public string Cliente { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
    /// <summary>Dias no status atual (como no relatório "Isotank Vazio - Dias no Status" do BI).</summary>
    public int? DiasNoStatus { get; set; }
    public DateTime? PrevisaoLiberacao { get; set; }
    /// <summary>Data de entrada no pátio (para "dias no pátio" total).</summary>
    public DateTime? DataEntrada { get; set; }
    /// <summary>Data em que entrou no status atual.</summary>
    public DateTime? DataInicioStatus { get; set; }
    public DateTime? DataHoraDescarregadoPatio { get; set; }
    public DateTime? DataHoraDescarregadoTerminal { get; set; }
    public DateTime? DataHoraCarregadoVeiculo { get; set; }
    public DateTime? PrevisaoChegadaTerminal { get; set; }
    public string? UrlFoto { get; set; }
    /// <summary>Várias fotos (URLs separadas por vírgula) para galeria.</summary>
    public string? UrlsFotos { get; set; }
    public string? PlacaVeiculo { get; set; }
    public string? Tipo { get; set; }
    public string? ProprietarioArmador { get; set; }
    public DateTime? SlaLimite { get; set; }
    public DateTime? TestePeriodicoVencimento { get; set; }
    public decimal? ReparoAcumuladoValor { get; set; }
    public string? Patio { get; set; }
    public string? Bloco { get; set; }
    public string? Fila { get; set; }
    public string? Pilha { get; set; }
    public string? UrlCertificadoLavagem { get; set; }
    public string? UrlLaudoVistoria { get; set; }
}