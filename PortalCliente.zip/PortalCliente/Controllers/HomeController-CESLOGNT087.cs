using System.Diagnostics;
using System.Net;
using System.Net.Mail;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PortalCliente.Models;
using PortalCliente.Services;

namespace PortalCliente.Controllers;

[Authorize] // toda a home exige login
public class HomeController : Controller
{
    private readonly IOrigenDadosService _origen;
    private readonly IConfiguration _configuration;
    private readonly UserManager<UsuarioAplicacao> _userManager;
    private readonly IConfiguracaoContatoService _configContato;

    public HomeController(
        IOrigenDadosService origen,
        IConfiguration configuration,
        UserManager<UsuarioAplicacao> userManager,
        IConfiguracaoContatoService configContato)
    {
        _origen = origen;
        _configuration = configuration;
        _userManager = userManager;
        _configContato = configContato;
    }

    private const int PaginaPadrao = 1;
    private const int ItensPorPaginaPadrao = 20;

    public async Task<IActionResult> Index(
        string? busca,
        string? cliente,
        string? status,
        string? ordenarPor = "Codigo",
        bool ordemAsc = true,
        int pagina = PaginaPadrao,
        int itensPorPagina = ItensPorPaginaPadrao)
    {
        itensPorPagina = Math.Clamp(itensPorPagina, 5, 100);
        pagina = Math.Max(1, pagina);

        var usuario = await _userManager.GetUserAsync(User);
        var ehAdmin = User.IsInRole("Admin");

        // Cliente comum: sempre filtra pelo próprio cliente, ignora parâmetro da querystring
        if (!ehAdmin)
            cliente = usuario?.ClienteNome;

        var todos = await _origen.GetIsotanquesAsync(cliente, status, busca);

        var ordenado = ordenarPor switch
        {
            "Produto"            => ordemAsc ? todos.OrderBy(c => c.Produto)            : todos.OrderByDescending(c => c.Produto),
            "Status"             => ordemAsc ? todos.OrderBy(c => c.Status)             : todos.OrderByDescending(c => c.Status),
            "PrevisaoLiberacao"  => ordemAsc ? todos.OrderBy(c => c.PrevisaoLiberacao)  : todos.OrderByDescending(c => c.PrevisaoLiberacao),
            "Cliente"            => ordemAsc ? todos.OrderBy(c => c.Cliente)            : todos.OrderByDescending(c => c.Cliente),
            "DiasNoStatus"       => ordemAsc ? todos.OrderBy(c => c.DiasNoStatus ?? int.MaxValue) : todos.OrderByDescending(c => c.DiasNoStatus ?? -1),
            _                    => ordemAsc ? todos.OrderBy(c => c.Codigo)             : todos.OrderByDescending(c => c.Codigo),
        };

        var totalItens = todos.Count;
        var totalPaginas = totalItens == 0 ? 1 : (int)Math.Ceiling(totalItens / (double)itensPorPagina);
        pagina = Math.Min(pagina, totalPaginas);

        var lista = ordenado
            .Skip((pagina - 1) * itensPorPagina)
            .Take(itensPorPagina)
            .ToList();

        // Dropdown de cliente só para Admin
        var clientes = ehAdmin ? await _origen.GetClientesAsync() : new List<string>();
        var statusList = await _origen.GetStatusListAsync();

        // Cards: contagens a partir da lista filtrada (todos)
        var porStatus = todos
            .GroupBy(c => c.Status)
            .ToDictionary(g => g.Key, g => g.Count());
        var alertasDias = todos.Count(c => (c.DiasNoStatus ?? 0) >= 15);
        var aguardandoAcao = todos.Count(c => c.Status == "Ag. Envio Estimativa");
        var hoje = DateTime.Today;
        var emSeteDias = hoje.AddDays(7);
        var proximasLiberacoes = todos.Count(c => c.PrevisaoLiberacao.HasValue && c.PrevisaoLiberacao.Value.Date >= hoje && c.PrevisaoLiberacao.Value.Date <= emSeteDias);

        ViewBag.EhAdmin = ehAdmin;
        ViewBag.Busca = busca;
        ViewBag.Cliente = cliente;
        ViewBag.Status = status;
        ViewBag.OrdenarPor = ordenarPor;
        ViewBag.OrdemAsc = ordemAsc;
        ViewBag.EstoqueTotal = totalItens;
        ViewBag.PaginaAtual = pagina;
        ViewBag.TotalPaginas = totalPaginas;
        ViewBag.TotalItens = totalItens;
        ViewBag.ItensPorPagina = itensPorPagina;
        ViewBag.Clientes = clientes;
        ViewBag.StatusList = statusList;
        ViewBag.PorStatus = porStatus;
        ViewBag.AlertasDias = alertasDias;
        ViewBag.AguardandoAcao = aguardandoAcao;
        ViewBag.ProximasLiberacoes = proximasLiberacoes;
        ViewBag.UltimaAtualizacao = DateTime.Now;
        return View(lista);
    }

    public async Task<IActionResult> Detalhe(string? codigo)
    {
        if (string.IsNullOrWhiteSpace(codigo))
            return RedirectToAction(nameof(Index));

        var item = await _origen.GetIsotanquePorCodigoAsync(codigo.Trim());

        if (item == null)
        {
            TempData["Mensagem"] = $"Isotank '{codigo}' não encontrado.";
            return RedirectToAction(nameof(Index));
        }

        // Cliente comum não pode acessar Isotank de outro cliente
        if (!User.IsInRole("Admin"))
        {
            var usuario = await _userManager.GetUserAsync(User);
            if (item.Cliente != usuario?.ClienteNome)
            {
                TempData["Mensagem"] = "Acesso negado a este Isotank.";
                return RedirectToAction(nameof(Index));
            }
        }

        return View(item);
    }

    /// <summary>Exporta os dados do isotank para CSV (abre no Excel).</summary>
    public async Task<IActionResult> ExportarDetalheExcel(string? codigo)
    {
        if (string.IsNullOrWhiteSpace(codigo))
            return RedirectToAction(nameof(Index));

        var item = await _origen.GetIsotanquePorCodigoAsync(codigo.Trim());
        if (item == null)
        {
            TempData["Mensagem"] = $"Isotank '{codigo}' não encontrado.";
            return RedirectToAction(nameof(Index));
        }

        if (!User.IsInRole("Admin"))
        {
            var usuario = await _userManager.GetUserAsync(User);
            if (item.Cliente != usuario?.ClienteNome)
            {
                TempData["Mensagem"] = "Acesso negado a este Isotank.";
                return RedirectToAction(nameof(Index));
            }
        }

        var sb = new System.Text.StringBuilder();
        sb.AppendLine("Campo;Valor");
        sb.AppendLine($"Código;{EscapeCsv(item.Codigo)}");
        sb.AppendLine($"Produto;{EscapeCsv(item.Produto)}");
        sb.AppendLine($"Cliente;{EscapeCsv(item.Cliente)}");
        sb.AppendLine($"Status;{EscapeCsv(item.Status)}");
        sb.AppendLine($"Dias no status;{item.DiasNoStatus?.ToString() ?? "–"}");
        sb.AppendLine($"Previsão liberação;{(item.PrevisaoLiberacao?.ToString("dd/MM/yyyy") ?? "–")}");
        sb.AppendLine($"Descarregado no pátio;{(item.DataHoraDescarregadoPatio?.ToString("dd/MM/yyyy HH:mm") ?? "–")}");
        sb.AppendLine($"Carregado no veículo;{(item.DataHoraCarregadoVeiculo?.ToString("dd/MM/yyyy HH:mm") ?? "–")}");
        sb.AppendLine($"Placa veículo;{EscapeCsv(item.PlacaVeiculo ?? "–")}");
        sb.AppendLine($"Previsão chegada terminal;{(item.PrevisaoChegadaTerminal?.ToString("dd/MM/yyyy HH:mm") ?? "–")}");
        var csv = System.Text.Encoding.UTF8.GetBytes(sb.ToString());
        var bom = System.Text.Encoding.UTF8.GetPreamble();
        var withBom = new byte[bom.Length + csv.Length];
        Buffer.BlockCopy(bom, 0, withBom, 0, bom.Length);
        Buffer.BlockCopy(csv, 0, withBom, bom.Length, csv.Length);
        var fileName = $"Isotank_{item.Codigo}_{DateTime.Now:yyyyMMdd_HHmm}.csv";
        return File(withBom, "text/csv; charset=utf-8", fileName);
    }

    private static string EscapeCsv(string value)
    {
        if (string.IsNullOrEmpty(value)) return value;
        if (value.Contains(';') || value.Contains('"') || value.Contains('\n'))
            return "\"" + value.Replace("\"", "\"\"") + "\"";
        return value;
    }

    /// <summary>Dashboard com totais por etapa, alertas e previsões. Admin vê tabela por cliente.</summary>
    public async Task<IActionResult> Dashboard()
    {
        var usuario = await _userManager.GetUserAsync(User);
        var ehAdmin = User.IsInRole("Admin");
        var cliente = ehAdmin ? null : usuario?.ClienteNome;

        var todos = await _origen.GetIsotanquesAsync(cliente, null, null);
        var hoje = DateTime.Today;
        var emSeteDias = hoje.AddDays(7);

        var porStatus = todos.GroupBy(c => c.Status).ToDictionary(g => g.Key, g => g.Count());
        int GetStatus(string s) => porStatus.TryGetValue(s, out var n) ? n : 0;

        ViewBag.EhAdmin = ehAdmin;
        ViewBag.NomeCompleto = usuario?.NomeCompleto ?? User.Identity?.Name ?? "Usuário";
        ViewBag.EstoqueTotal = todos.Count;
        ViewBag.AgLimpeza = GetStatus("Ag. Limpeza");
        ViewBag.AgReparo = GetStatus("Ag. Reparo");
        ViewBag.AgInspecao = GetStatus("Ag. Inspeção");
        ViewBag.AgEnvioEstimativa = GetStatus("Ag. Envio Estimativa");
        ViewBag.AgOffHire = GetStatus("Ag. Off Hire");
        ViewBag.AlertasDias = todos.Count(c => (c.DiasNoStatus ?? 0) >= 10);
        ViewBag.ProximasLiberacoes = todos.Count(c => c.PrevisaoLiberacao.HasValue && c.PrevisaoLiberacao.Value.Date >= hoje && c.PrevisaoLiberacao.Value.Date <= emSeteDias);
        ViewBag.Cliente = cliente;

        var proximasLista = todos
            .Where(c => c.PrevisaoLiberacao.HasValue && c.PrevisaoLiberacao.Value.Date >= hoje && c.PrevisaoLiberacao.Value.Date <= emSeteDias)
            .OrderBy(c => c.PrevisaoLiberacao)
            .Take(5)
            .ToList();
        ViewBag.ProximasLiberacoesLista = proximasLista;

        var porProduto = todos
            .GroupBy(c => c.Produto ?? "(sem produto)")
            .OrderByDescending(g => g.Count())
            .ThenBy(g => g.Key)
            .Select(g => new { Produto = g.Key, Total = g.Count() })
            .ToList();
        ViewBag.ProdutosLabels = porProduto.Select(p => p.Produto).ToList();
        ViewBag.ProdutosData = porProduto.Select(p => p.Total).ToList();

        if (ehAdmin)
        {
            var porCliente = todos
                .GroupBy(c => c.Cliente)
                .Select(g => new { Cliente = g.Key, Total = g.Count(), Lista = g.ToList() })
                .OrderBy(x => x.Cliente)
                .ToList();
            ViewBag.PorCliente = porCliente;
        }

        ViewBag.UltimaAtualizacao = DateTime.Now;
        return View();
    }

    /// <summary>Isotanks críticos: parados (DiasNoStatus >= 10) e previsões vencidas/próximas (até 3 dias).</summary>
    public async Task<IActionResult> Alertas()
    {
        var usuario = await _userManager.GetUserAsync(User);
        var ehAdmin = User.IsInRole("Admin");
        var cliente = ehAdmin ? null : usuario?.ClienteNome;

        var todos = await _origen.GetIsotanquesAsync(cliente, null, null);
        var hoje = DateTime.Today;
        var limitePrevisao = hoje.AddDays(3);

        var parados = todos
            .Where(c => (c.DiasNoStatus ?? 0) >= 10)
            .OrderByDescending(c => c.DiasNoStatus ?? 0)
            .ThenBy(c => c.Codigo)
            .ToList();
        var previsoes = todos
            .Where(c => c.PrevisaoLiberacao.HasValue && c.PrevisaoLiberacao.Value.Date <= limitePrevisao)
            .OrderBy(c => c.PrevisaoLiberacao)
            .ThenBy(c => c.Codigo)
            .ToList();

        var codigosCriticos = parados.Select(c => c.Codigo).Union(previsoes.Select(c => c.Codigo)).ToHashSet();
        ViewBag.EhAdmin = ehAdmin;
        ViewBag.Parados = parados;
        ViewBag.Previsoes = previsoes;
        ViewBag.TotalCriticos = codigosCriticos.Count;
        ViewBag.UltimaAtualizacao = DateTime.Now;
        return View();
    }

    /// <summary>Tela para o cliente entrar em contato com a Depotce (WhatsApp / e-mail).</summary>
    public async Task<IActionResult> Contato(string? codigo)
    {
        var config = await _configContato.GetAsync();
        ViewBag.WhatsAppNumero = config?.WhatsAppNumero?.Trim() ?? _configuration["Contato:WhatsAppNumero"]?.Trim() ?? "";
        ViewBag.Email = config?.EmailDestino?.Trim() ?? _configuration["Contato:Email"]?.Trim() ?? "";
        ViewBag.NomeEquipe = config?.NomeEquipe?.Trim() ?? _configuration["Contato:NomeEquipe"]?.Trim() ?? "Depotce";
        ViewBag.CodigoPre = codigo ?? "";

        Container? isotanque = null;
        if (!string.IsNullOrWhiteSpace(codigo))
        {
            isotanque = await _origen.GetIsotanquePorCodigoAsync(codigo.Trim());
            if (isotanque != null && !User.IsInRole("Admin"))
            {
                var usuario = await _userManager.GetUserAsync(User);
                if (isotanque.Cliente != usuario?.ClienteNome)
                    isotanque = null;
            }
        }
        ViewBag.Isotanque = isotanque;

        var smtpHost = config?.SmtpHost?.Trim() ?? _configuration["Contato:SmtpHost"]?.Trim();
        var smtpUser = config?.SmtpUser?.Trim() ?? _configuration["Contato:SmtpUser"]?.Trim();
        ViewBag.EmailEnviadoPeloSite = !string.IsNullOrWhiteSpace(smtpHost) && !string.IsNullOrWhiteSpace(smtpUser);
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> EnviarEmail(string? Codigo, string? Assunto, string? Mensagem)
    {
        var config = await _configContato.GetAsync();
        var destino = config?.EmailDestino?.Trim() ?? _configuration["Contato:Email"]?.Trim();
        if (string.IsNullOrWhiteSpace(destino))
        {
            TempData["ContatoErro"] = "E-mail de destino não configurado. Um administrador pode definir em Configurações de contato.";
            return RedirectToAction(nameof(Contato), new { codigo = Codigo });
        }

        var smtpHost = config?.SmtpHost?.Trim() ?? _configuration["Contato:SmtpHost"]?.Trim();
        if (string.IsNullOrWhiteSpace(smtpHost))
        {
            TempData["ContatoErro"] = "SMTP não configurado. Um administrador pode definir a conta de envio em Configurações de contato.";
            return RedirectToAction(nameof(Contato), new { codigo = Codigo });
        }

        var usuario = await _userManager.GetUserAsync(User);
        var nomeEquipe = config?.NomeEquipe?.Trim() ?? _configuration["Contato:NomeEquipe"]?.Trim() ?? "Depotce";
        var codigo = (Codigo ?? "").Trim().ToUpper();
        var assunto = (Assunto ?? "").Trim();
        if (string.IsNullOrWhiteSpace(assunto)) assunto = "Solicitação";

        var corpo = $"Olá, {nomeEquipe}!";
        if (!string.IsNullOrEmpty(codigo)) corpo += $"\r\n\r\nIsotank: {codigo}";
        corpo += $"\r\nAssunto: {assunto}";
        if (!string.IsNullOrWhiteSpace(Mensagem)) corpo += $"\r\n\r\n{Mensagem}";
        if (string.IsNullOrEmpty(codigo) && string.IsNullOrWhiteSpace(Mensagem)) corpo += "\r\n\r\nGostaria de obter informações.";
        corpo += $"\r\n\r\n---\r\nEnviado pelo Portal do Cliente por {usuario?.NomeCompleto ?? User.Identity?.Name ?? "Cliente"} ({usuario?.Email ?? "—"})";

        var subject = string.IsNullOrEmpty(codigo)
            ? $"[Portal Depotce] {assunto}"
            : $"[Portal Depotce] {assunto} – {codigo}";

        var smtpUser = config?.SmtpUser?.Trim() ?? _configuration["Contato:SmtpUser"]?.Trim();
        var smtpPassword = !string.IsNullOrEmpty(config?.SmtpUser)
            ? await _configContato.GetSmtpPasswordPlainAsync()
            : _configuration["Contato:SmtpPassword"];

        try
        {
            var fromEmail = config?.FromEmail?.Trim() ?? _configuration["Contato:FromEmail"]?.Trim() ?? destino;
            var fromName = config?.FromName?.Trim() ?? _configuration["Contato:FromName"]?.Trim() ?? "Portal do Cliente Depotce";
            if (string.IsNullOrWhiteSpace(fromEmail) && !string.IsNullOrEmpty(smtpUser))
                fromEmail = smtpUser;

            using var client = new SmtpClient(smtpHost)
            {
                Port = config?.SmtpPort ?? (int.TryParse(_configuration["Contato:SmtpPort"], out var p) ? p : 587),
                EnableSsl = config?.SmtpEnableSsl ?? string.Equals(_configuration["Contato:SmtpEnableSsl"], "true", StringComparison.OrdinalIgnoreCase),
                Credentials = !string.IsNullOrEmpty(smtpUser) ? new NetworkCredential(smtpUser, smtpPassword ?? "") : null
            };

            var mail = new MailMessage
            {
                From = new MailAddress(fromEmail, fromName),
                Subject = subject,
                Body = corpo,
                IsBodyHtml = false
            };
            mail.To.Add(destino);
            if (!string.IsNullOrWhiteSpace(usuario?.Email))
                mail.ReplyToList.Add(new MailAddress(usuario.Email, usuario.NomeCompleto ?? usuario.Email));

            await client.SendMailAsync(mail);
            TempData["ContatoSucesso"] = "E-mail enviado com sucesso. Nossa equipe responderá em breve.";
        }
        catch (Exception)
        {
            TempData["ContatoErro"] = "Não foi possível enviar o e-mail. Tente novamente ou use o WhatsApp.";
        }

        return RedirectToAction(nameof(Contato), new { codigo = Codigo });
    }

    public IActionResult Relatorios()
    {
        var biUrl = _configuration["Bi:IsotankVazioUrl"];
        var biTitulo = _configuration["Bi:TituloIsotankVazio"] ?? "Isotank Vazio - Dias no Status";
        ViewBag.BiUrl = biUrl;
        ViewBag.BiTitulo = biTitulo;
        return View();
    }

    public IActionResult Privacy() => View();

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}