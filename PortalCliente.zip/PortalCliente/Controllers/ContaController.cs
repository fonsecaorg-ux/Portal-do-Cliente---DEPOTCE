using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using PortalCliente.Data;
using PortalCliente.Models;
using PortalCliente.Services;

namespace PortalCliente.Controllers;

public class ContaController : Controller
{
    private readonly SignInManager<UsuarioAplicacao> _signIn;
    private readonly UserManager<UsuarioAplicacao> _userManager;
    private readonly IOrigenDadosService _origen;

    public ContaController(
        SignInManager<UsuarioAplicacao> signIn,
        UserManager<UsuarioAplicacao> userManager,
        IOrigenDadosService origen)
    {
        _signIn = signIn;
        _userManager = userManager;
        _origen = origen;
    }

    // ──────────────────────────────────────────────
    // LOGIN
    // ──────────────────────────────────────────────

    [HttpGet]
    public IActionResult Login(string? returnUrl = null)
    {
        if (User.Identity?.IsAuthenticated == true)
            return RedirectToAction("Index", "Home");

        ViewBag.ReturnUrl = returnUrl;
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Login(LoginViewModel model, string? returnUrl = null)
    {
        if (!ModelState.IsValid)
            return View(model);

        var result = await _signIn.PasswordSignInAsync(
            model.Email,
            model.Senha,
            model.LembrarMe,
            lockoutOnFailure: false);

        if (result.Succeeded)
        {
            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);
            return RedirectToAction("Index", "Home");
        }

        ModelState.AddModelError(string.Empty, "E-mail ou senha incorretos.");
        return View(model);
    }

    // ──────────────────────────────────────────────
    // LOGOUT
    // ──────────────────────────────────────────────

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Logout()
    {
        await _signIn.SignOutAsync();
        return RedirectToAction("Login");
    }

    // ──────────────────────────────────────────────
    // CADASTRO DE USUÁRIO (somente Admin)
    // ──────────────────────────────────────────────

    [HttpGet]
    [Authorize(Roles = IdentitySeedData.RoleAdmin)]
    public async Task<IActionResult> CadastrarUsuario()
    {
        var clientes = await _origen.GetClientesAsync();
        ViewBag.Clientes = clientes;
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    [Authorize(Roles = IdentitySeedData.RoleAdmin)]
    public async Task<IActionResult> CadastrarUsuario(CadastroUsuarioViewModel model)
    {
        // Validação extra: cliente vinculado obrigatório para role Cliente
        if (model.Role == IdentitySeedData.RoleCliente && string.IsNullOrWhiteSpace(model.ClienteNome))
            ModelState.AddModelError(nameof(model.ClienteNome), "Selecione o cliente vinculado.");

        if (!ModelState.IsValid)
        {
            ViewBag.Clientes = await _origen.GetClientesAsync();
            return View(model);
        }

        var usuario = new UsuarioAplicacao
        {
            UserName = model.Email,
            Email = model.Email,
            NomeCompleto = model.NomeCompleto,
            ClienteNome = model.Role == IdentitySeedData.RoleCliente ? model.ClienteNome : null,
            EmailConfirmed = true
        };

        var result = await _userManager.CreateAsync(usuario, model.Senha);

        if (!result.Succeeded)
        {
            foreach (var error in result.Errors)
                ModelState.AddModelError(string.Empty, error.Description);

            ViewBag.Clientes = await _origen.GetClientesAsync();
            return View(model);
        }

        await _userManager.AddToRoleAsync(usuario, model.Role);

        TempData["Mensagem"] = $"Usuário '{model.Email}' cadastrado com sucesso.";
        return RedirectToAction(nameof(ListarUsuarios));
    }

    // ──────────────────────────────────────────────
    // LISTAGEM DE USUÁRIOS (somente Admin)
    // ──────────────────────────────────────────────

    [HttpGet]
    [Authorize(Roles = IdentitySeedData.RoleAdmin)]
    public IActionResult ListarUsuarios()
    {
        var usuarios = _userManager.Users.OrderBy(u => u.NomeCompleto).ToList();
        return View(usuarios);
    }

    // ──────────────────────────────────────────────
    // ACESSO NEGADO
    // ──────────────────────────────────────────────

    public IActionResult AcessoNegado()
    {
        return View();
    }
}
